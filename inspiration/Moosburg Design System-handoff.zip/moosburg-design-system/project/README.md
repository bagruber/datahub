# Moosburg Design System
**Stadt Moosburg an der Isar — "Die Drei-Rosen-Stadt"**

## Overview

Moosburg an der Isar is a small Bavarian town near Munich with over 1,250 years of history. Its brand balances tradition and modernity — rooted in civic pride, Bavarian culture, and community engagement. The visual identity was developed prominently for the **1250-Jahr-Feier** (1250th anniversary celebration in 2022) and extends into ongoing municipal communications.

The town's nickname is **"Drei-Rosen-Stadt"** (City of Three Roses), derived from its coat of arms: a heraldic shield with a crown bearing two deep-red roses on a white field (top half) and one white rose on a deep-red field (bottom half).

### Products / Surfaces
- **Municipal website** — mein.moosburg.de (citizen portal)
- **Print materials** — anniversary magazine ("Unser Rückblick 2022"), event programs, flyers, beer coasters, pins
- **Event branding** — 1250-Jahr-Feier, Stalag VII A memorial events, festivals

### Source Assets
- Uploaded brand images (webp/jpg) — magazine spreads, beer coasters, pins, coat of arms, event flyer
- `uploads/moosburg.svg` — official Stadt Moosburg logo SVG

---

## CONTENT FUNDAMENTALS

**Language:** German (primary). Formal yet warm civic tone.

**Voice & Tone:**
- Proud and community-oriented ("Wir" — we, together)
- Warm, celebratory, historically conscious
- Approachable — not bureaucratic stiffness; reads more like a community magazine than a government notice
- Uses "Sie" (formal you) in official contexts, "wir" in collective/community contexts
- Exclamatory and enthusiastic for events: *"Der Festzug begeistert sogar Ministerpräsident Söder!"*

**Casing:**
- Headlines: Title Case or ALL CAPS for major display text
- Subheadings: Mixed case with script accent
- Body: Sentence case

**Punctuation:** German quotation marks („ ") used. Em-dashes (—) and en-dashes (–) used typographically.

**Emoji:** Never used in official communications.

**Copy examples:**
- *"Die Stadt Moosburg freut sich darauf, mit Ihnen zusammen ein Stück Stadtgeschichte zu schreiben."*
- *"Unglaublich schiet was!" / "Von den Anfängen bis heute"*
- *"DANKE Moosburg"*
- *"Interessant für alle Bürgerinnen und Bürger, Schüler, Lehrer, Vereine, Verbände..."*

---

## VISUAL FOUNDATIONS

### Colors
- **Primary Deep Red:** `#C8102E` — coat of arms red; main brand color; used for large display numerals, key headlines, shield background
- **Primary Gold/Beige:** `#B8964E` — warm golden tone; used for magazine cover backgrounds, pull-quote blocks, illustrative cityscape tint
- **Light Gold:** `#E8D5A3` — soft background wash; used in lower magazine cover area
- **Cream/Off-white:** `#FAF7F2` — page backgrounds, light content areas
- **Dark Ink:** `#1C1C1C` — primary body text
- **Mid Gray:** `#888888` — secondary/caption text
- **Purple Accent:** `#6B3E7A` — used in event flyers for section headers (secondary accent)
- **White:** `#FFFFFF`

**Rainbow Accent Stripe** (9 colors, used as horizontal decorative line):
Pink `#E91E8C` → Red `#E5202E` → Orange `#F4830A` → Yellow `#F5D400` → Green `#0A9E4C` → Blue `#009AC7` → Indigo `#3B3F9A` → Brown `#8B4A2A` → Black `#1A1A1A`

### Typography
- **Display/Heading:** Playfair Display (Bold, Condensed where possible) — vintage serif, authoritative, slightly ornate. *Substitution for original. Original appears to be a heavier display serif.*
- **Script Accent:** Pinyon Script or Great Vibes — flowing handwritten cursive, used as subtitle decorative accent (e.g. "Moosburg", "Rückblick", "bis heute")
- **Sans Body:** DM Sans — clean, modern, readable at small sizes
- **City Name/Caps Label:** Montserrat — geometric caps for "MOOSBURG AN DER ISAR" style labels

### Backgrounds
- White pages with full-bleed photography
- Gold/beige wash areas (half-page blocks) for pull-quotes and cover lower sections
- Cityscape line-art illustrations tinted in gold — used as decorative watermark-style backgrounds
- The rainbow stripe is always used as a thin (3–4px) horizontal rule accent, never as a fill

### Animation
- Print-first brand; no digital animation guidelines established
- For digital: subtle fade-ins, no bounce or spring — dignified, slow transitions (300–500ms ease-in-out)

### Imagery
- Warm, slightly warm-shifted photography of real people and community events
- Architectural photography of Moosburg's historic buildings (Rathaus, St. Kastulus Münster)
- Golden-sepia cityscape line illustrations used decoratively
- Never stock photography — always authentic local imagery

### Cards / Containers
- Minimal border usage; prefer white space
- Gold accent blocks as callout containers (no rounded corners in print)
- For digital: subtle shadow `0 2px 12px rgba(0,0,0,0.08)`, minimal rounding `4px`

### Corner Radii
- Print: 0 (sharp)
- Digital: 4px for cards, 2px for buttons

### Iconography
See ICONOGRAPHY section below.

### Hover / Press States (digital)
- Hover: slight darkening of red (`#A50D24`), gold brightens slightly
- Links: red underline
- Buttons: darken on hover, slight scale-down (0.97) on press

---

## ICONOGRAPHY

**Approach:** The brand does not use a standard icon system. Iconography is heraldic/illustrative:
- The **Coat of Arms** (Wappen) is the primary brand icon — used on all official materials
- **Line-art cityscape illustrations** (Rathaus, church towers) in gold tint — used decoratively
- No icon font identified; no CDN icon set in use
- For digital interfaces, **Lucide Icons** (CDN) is recommended as the closest stylistically-neutral match (thin stroke, clean)

**Assets available in `assets/`:**
- `moosburg-logo.svg` — official Stadt Moosburg SVG logo
- `coat-of-arms-1250.jpg` — large coat of arms for 1250 anniversary
- `magazine-cover.webp`, `magazine-spread-1.webp` — brand reference
- `beer-coaster.webp` — circular brand application
- `event-flyer.jpg` — municipal event program reference

---

## FILE INDEX

```
README.md                         — This file
SKILL.md                          — Agent skill descriptor
colors_and_type.css               — CSS variables (colors + typography)
assets/
  moosburg-logo.svg               — Official Stadt Moosburg logo
  coat-of-arms-1250.jpg           — 1250 Jahre coat of arms
  magazine-cover.webp             — Magazine cover reference
  magazine-spread-1.webp          — Interior magazine spread
  beer-coaster.webp               — Branded beer coaster
  event-flyer.jpg                 — Event program/flyer
preview/
  colors-primary.html             — Primary color swatches
  colors-rainbow.html             — Rainbow accent stripe
  colors-semantic.html            — Semantic color tokens
  type-display.html               — Display/heading type scale
  type-body.html                  — Body and UI type
  type-script.html                — Script accent specimens
  spacing-tokens.html             — Spacing & radius tokens
  shadows-borders.html            — Shadow + border system
  logo-badge.html                 — Logo & coat of arms usage
  rainbow-stripe.html             — Rainbow stripe component
  buttons.html                    — Button variants
  cards.html                      — Card components
  badges-tags.html                — Badges and tags
  navigation.html                 — Nav header component
ui_kits/
  moosburg-website/
    index.html                    — Interactive website prototype
    Header.jsx
    Hero.jsx
    EventCard.jsx
    Footer.jsx
```
