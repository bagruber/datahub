/*
 * Moosburg UI Kit — Shared Components v2
 * Design rules:
 *  - Playfair Display: ALL CAPS for all headings
 *  - Script (Madelon Script): large, overlapping behind/over serif headings
 *  - DM Sans: unified sans, weight 400/500/600 only (no 300)
 *  - Buttons: 44px height, pill-style badges
 *  - Rainbow stripe: segmented, never gradient
 */

const RAINBOW_COLORS = ['#E91E8C','#E5202E','#F4830A','#F5D400','#0A9E4C','#009AC7','#3B3F9A','#8B4A2A','#1A1A1A'];
const RAINBOW_FLEX   = [1.1, 1.3, 0.9, 1.2, 1.0, 1.1, 0.8, 1.0, 0.6];

function RainbowStripe({ height = 4, width = '100%', opacity = 1, marginTop = 0 }) {
  return React.createElement('div', { style: { display:'flex', height, width, overflow:'hidden', marginTop, opacity, flexShrink:0 }},
    RAINBOW_COLORS.map((c, i) => React.createElement('div', { key:i, style:{ background:c, flex:RAINBOW_FLEX[i] }}))
  );
}

// Overlapping script + serif heading
function DisplayHeading({ script, heading, scriptSize = '4rem', headingSize = '2rem', color = '#1C1C1C', scriptColor = '#B8964E', scriptTop = 0, scriptLeft = -4, headingMarginTop = 24 }) {
  return React.createElement('div', { style:{ position:'relative', paddingTop: headingMarginTop }},
    script && React.createElement('span', { style:{
      fontFamily:"'Madelon Script',cursive", fontSize: scriptSize, color: scriptColor,
      position:'absolute', top: scriptTop, left: scriptLeft,
      lineHeight:1, zIndex:0, pointerEvents:'none', whiteSpace:'nowrap', opacity:0.92
    }}, script),
    React.createElement('div', { style:{
      fontFamily:"'Playfair Display',serif", fontSize: headingSize,
      fontWeight:900, textTransform:'uppercase', color, lineHeight:1.05,
      position:'relative', zIndex:1, letterSpacing:'-0.01em'
    }}, heading)
  );
}

// ── Header ──────────────────────────────────────────────────────
function Header({ activePage, onNav }) {
  const links = ['Aktuelles', 'Bürgerservice', 'Veranstaltungen', 'Stadtrat', 'Geschichte'];
  return React.createElement('div', null,
    React.createElement(RainbowStripe, { height: 4 }),
    React.createElement('nav', { style:{
      background:'#fff', borderBottom:'1px solid #E0D8CC', padding:'0 32px',
      display:'flex', alignItems:'center', gap:32, height:60
    }},
      React.createElement('a', { href:'#', onClick:e=>{ e.preventDefault(); onNav&&onNav('home'); },
        style:{ display:'flex', alignItems:'center', gap:10, textDecoration:'none' }},
        React.createElement('img', { src:'../../assets/moosburg-logo.svg', width:38, height:38, alt:'Moosburg' }),
        React.createElement('div', { style:{ fontFamily:"'Montserrat',sans-serif", fontSize:11, fontWeight:700,
          letterSpacing:'0.1em', textTransform:'uppercase', color:'#1C1C1C', lineHeight:1.3 }},
          React.createElement('div', null, 'Stadt'),
          React.createElement('div', null, 'Moosburg')
        )
      ),
      React.createElement('div', { style:{ display:'flex', gap:24, alignItems:'center', flex:1, marginLeft:8 }},
        links.map(l => React.createElement('a', {
          key:l, href:'#', onClick:e=>{ e.preventDefault(); onNav&&onNav(l); },
          style:{ fontSize:14, fontWeight: activePage===l ? 600 : 400,
            textDecoration:'none', color: activePage===l ? '#C8102E' : '#555',
            borderBottom: activePage===l ? '2px solid #C8102E' : '2px solid transparent',
            paddingBottom:2, transition:'all 0.2s' }
        }, l))
      ),
      React.createElement('a', { href:'#', style:{
        background:'#C8102E', color:'#fff', padding:'0 18px', height:38,
        borderRadius:4, fontSize:13, fontWeight:600, textDecoration:'none',
        display:'inline-flex', alignItems:'center', gap:6, letterSpacing:'0.01em'
      }}, 'mein.moosburg.de ', React.createElement('span', null, '→'))
    )
  );
}

// ── Hero ─────────────────────────────────────────────────────────
function Hero({ onCTA }) {
  return React.createElement('div', { style:{
    position:'relative', overflow:'hidden', minHeight:480, display:'flex', alignItems:'center'
  }},
    // Full-bleed photo background
    React.createElement('div', { style:{
      position:'absolute', inset:0,
      backgroundImage:'url(../../assets/photo-city.jpg)',
      backgroundSize:'cover', backgroundPosition:'center 60%'
    }}),
    // Dark overlay
    React.createElement('div', { style:{ position:'absolute', inset:0, background:'linear-gradient(100deg, rgba(28,28,28,0.82) 0%, rgba(28,28,28,0.55) 60%, rgba(28,28,28,0.15) 100%)' }}),
    // Content
    React.createElement('div', { style:{ position:'relative', zIndex:1, padding:'72px 48px', maxWidth:620 }},
      React.createElement('div', { style:{ fontFamily:"'Montserrat',sans-serif", fontSize:11, fontWeight:700,
        letterSpacing:'0.18em', textTransform:'uppercase', color:'rgba(255,255,255,0.6)', marginBottom:8 }},
        'Drei-Rosen-Stadt · Seit 772 n. Chr.'
      ),
      // Overlapping script + heading
      React.createElement('div', { style:{ position:'relative', paddingTop:52, marginBottom:24 }},
        React.createElement('span', { style:{
          fontFamily:"'Madelon Script',cursive", fontSize:'5.5rem', color:'rgba(184,150,78,0.85)',
          position:'absolute', top:0, left:-4, lineHeight:1, zIndex:0, pointerEvents:'none'
        }}, 'Willkommen in'),
        React.createElement('h1', { style:{
          fontFamily:"'Playfair Display',serif", fontWeight:900, textTransform:'uppercase',
          fontSize:'clamp(2.2rem,4.5vw,3.2rem)', color:'#fff', lineHeight:1.05,
          position:'relative', zIndex:1, letterSpacing:'-0.01em'
        }}, 'Moosburg an der Isar')
      ),
      React.createElement('p', { style:{ fontSize:16, fontWeight:400, color:'rgba(255,255,255,0.82)', lineHeight:1.7, marginBottom:32, maxWidth:480 }},
        'Die Stadt Moosburg freut sich darauf, mit Ihnen zusammen ein Stück Stadtgeschichte zu schreiben.'
      ),
      React.createElement('div', { style:{ display:'flex', gap:12 }},
        React.createElement('button', { onClick:onCTA, style:{
          background:'#C8102E', color:'#fff', border:'none', height:46,
          padding:'0 28px', borderRadius:4, fontSize:14, fontWeight:600, cursor:'pointer',
          display:'flex', alignItems:'center', gap:8
        }}, 'Veranstaltungen ', React.createElement('span', null, '→')),
        React.createElement('button', { style:{
          background:'transparent', color:'#fff', border:'2px solid rgba(255,255,255,0.5)',
          height:46, padding:'0 24px', borderRadius:4, fontSize:14, fontWeight:600, cursor:'pointer'
        }}, 'Bürgerservice')
      )
    )
  );
}

// ── EventCard ─────────────────────────────────────────────────────
function EventCard({ tag, title, desc, date, location, accent, image }) {
  const color = accent==='gold' ? '#B8964E' : accent==='purple' ? '#6B3E7A' : '#C8102E';
  return React.createElement('div', { style:{
    background:'#fff', borderRadius:4, boxShadow:'0 2px 12px rgba(0,0,0,0.08)',
    overflow:'hidden', display:'flex', flexDirection:'column'
  }},
    image
      ? React.createElement('div', { style:{ height:120, overflow:'hidden' }},
          React.createElement('img', { src:image, alt:title, style:{ width:'100%', height:'100%', objectFit:'cover' }}))
      : React.createElement('div', { style:{ height:6, background:color }}),
    React.createElement('div', { style:{ padding:'14px 16px', flex:1 }},
      React.createElement('div', { style:{ fontSize:10, fontWeight:600, letterSpacing:'0.12em',
        textTransform:'uppercase', color, marginBottom:5, fontFamily:"'DM Sans',sans-serif" }}, tag),
      React.createElement('div', { style:{ fontFamily:"'Playfair Display',serif", fontSize:15,
        fontWeight:700, textTransform:'uppercase', color:'#1C1C1C', lineHeight:1.2, marginBottom:7 }}, title),
      desc && React.createElement('div', { style:{ fontSize:12, color:'#555', lineHeight:1.55, marginBottom:10 }}, desc),
      React.createElement('div', { style:{ borderTop:'1px solid #E0D8CC', paddingTop:9,
        display:'flex', justifyContent:'space-between', alignItems:'center' }},
        React.createElement('span', { style:{ fontSize:11, color:'#888' }}, date),
        React.createElement('span', { style:{ fontSize:11, color:'#888' }}, location)
      )
    )
  );
}

// ── NewsItem ──────────────────────────────────────────────────────
function NewsItem({ tag, title, excerpt, date }) {
  return React.createElement('div', { style:{
    display:'flex', gap:14, padding:'15px 0', borderBottom:'1px solid #E0D8CC', alignItems:'flex-start'
  }},
    React.createElement('div', { style:{ width:3, flexShrink:0, background:'#C8102E', borderRadius:2, alignSelf:'stretch', minHeight:40 }}),
    React.createElement('div', { style:{ flex:1 }},
      React.createElement('div', { style:{ fontSize:10, fontWeight:600, letterSpacing:'0.1em',
        textTransform:'uppercase', color:'#C8102E', marginBottom:3 }}, tag),
      React.createElement('div', { style:{ fontFamily:"'Playfair Display',serif", fontSize:14,
        fontWeight:700, textTransform:'uppercase', color:'#1C1C1C', marginBottom:4, lineHeight:1.25 }}, title),
      React.createElement('div', { style:{ fontSize:12, color:'#555', lineHeight:1.5, marginBottom:4 }}, excerpt),
      React.createElement('div', { style:{ fontSize:11, color:'#888' }}, date)
    )
  );
}

// ── SectionHeader ────────────────────────────────────────────────
function SectionHeader({ label, heading, script, light = false }) {
  const textColor = light ? '#fff' : '#1C1C1C';
  const scriptColor = light ? 'rgba(255,255,255,0.5)' : '#B8964E';
  return React.createElement('div', { style:{ marginBottom:32 }},
    label && React.createElement('div', { style:{
      fontFamily:"'Montserrat',sans-serif", fontSize:10, fontWeight:700,
      letterSpacing:'0.18em', textTransform:'uppercase',
      color: light ? 'rgba(255,255,255,0.45)' : '#888', marginBottom:4
    }}, label),
    React.createElement('div', { style:{ position:'relative', paddingTop: script ? 44 : 0 }},
      script && React.createElement('span', { style:{
        fontFamily:"'Madelon Script',cursive", fontSize:'3.8rem', color:scriptColor,
        position:'absolute', top:0, left:-2, lineHeight:1, zIndex:0, pointerEvents:'none'
      }}, script),
      React.createElement('h2', { style:{
        fontFamily:"'Playfair Display',serif", fontSize:'clamp(1.5rem,3vw,2rem)',
        fontWeight:900, textTransform:'uppercase', color:textColor,
        lineHeight:1.1, position:'relative', zIndex:1
      }}, heading)
    ),
    React.createElement(RainbowStripe, { height:3, width:60, marginTop:10 })
  );
}

// ── Pill Badge ────────────────────────────────────────────────────
function Badge({ label, variant = 'red' }) {
  const styles = {
    red:    { bg:'#C8102E', color:'#fff' },
    gold:   { bg:'#B8964E', color:'#fff' },
    purple: { bg:'#6B3E7A', color:'#fff' },
    dark:   { bg:'#1C1C1C', color:'#fff' },
    cream:  { bg:'#E8D5A3', color:'#7A6030' },
    'outline-red': { bg:'transparent', color:'#C8102E', border:'1.5px solid #C8102E' },
  };
  const s = styles[variant] || styles.red;
  return React.createElement('span', { style:{
    display:'inline-flex', alignItems:'center', padding:'4px 12px',
    borderRadius:999, fontSize:11, fontWeight:600, letterSpacing:'0.03em',
    background:s.bg, color:s.color, border:s.border||'none'
  }}, label);
}

// ── Footer ────────────────────────────────────────────────────────
function Footer() {
  return React.createElement('footer', { style:{ background:'#1C1C1C', color:'#fff', padding:'48px 32px 24px' }},
    React.createElement('div', { style:{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:40, marginBottom:40 }},
      React.createElement('div', null,
        React.createElement('div', { style:{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }},
          React.createElement('img', { src:'../../assets/moosburg-logo.svg', width:40, height:40,
            style:{ filter:'brightness(0) invert(1)' }, alt:'Moosburg' }),
          React.createElement('div', { style:{ fontFamily:"'Montserrat',sans-serif", fontSize:10,
            fontWeight:700, letterSpacing:'0.1em', textTransform:'uppercase', color:'#fff', lineHeight:1.4 }},
            React.createElement('div', null, 'Stadt Moosburg'),
            React.createElement('div', null, 'a. d. Isar')
          )
        ),
        React.createElement('div', { style:{ fontSize:13, color:'rgba(255,255,255,0.55)', lineHeight:1.7 }},
          React.createElement('div', null, 'Stadtplatz 1'),
          React.createElement('div', null, '84328 Moosburg an der Isar')
        )
      ),
      React.createElement('div', null,
        React.createElement('div', { style:{ fontSize:10, fontWeight:700, letterSpacing:'0.12em',
          textTransform:'uppercase', color:'rgba(255,255,255,0.35)', marginBottom:14 }}, 'Bürgerservice'),
        ['Stadtrat','Veranstaltungen','Aktuelles','Bürgerportal'].map(l =>
          React.createElement('div', { key:l, style:{ fontSize:13, color:'rgba(255,255,255,0.65)', marginBottom:8, cursor:'pointer' }}, l)
        )
      ),
      React.createElement('div', null,
        React.createElement('div', { style:{ fontSize:10, fontWeight:700, letterSpacing:'0.12em',
          textTransform:'uppercase', color:'rgba(255,255,255,0.35)', marginBottom:14 }}, 'Kontakt'),
        React.createElement('div', { style:{ fontSize:13, color:'rgba(255,255,255,0.65)', marginBottom:8 }}, 'Tel. +49 8761 72-0'),
        React.createElement('div', { style:{ fontSize:13, color:'rgba(255,255,255,0.65)', marginBottom:8 }}, 'info@moosburg.de'),
        React.createElement('div', { style:{ fontSize:13, color:'rgba(255,255,255,0.65)' }}, 'mein.moosburg.de')
      )
    ),
    React.createElement('div', { style:{ height:1, background:'rgba(255,255,255,0.08)', marginBottom:20 }}),
    React.createElement('div', { style:{ display:'flex', justifyContent:'space-between', alignItems:'center' }},
      React.createElement('div', { style:{ fontSize:11, color:'rgba(255,255,255,0.3)' }}, '© 2024 Stadt Moosburg a. d. Isar'),
      React.createElement(RainbowStripe, { height:3, width:120 })
    )
  );
}

Object.assign(window, { Header, Hero, EventCard, NewsItem, Footer, SectionHeader, RainbowStripe, DisplayHeading, Badge });
